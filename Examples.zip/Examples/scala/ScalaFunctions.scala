package com

import scala.math._
object ScalaFunctions extends App {
  //Functions with Parameters having Default values
  
/*  def getSum(a: Int = 1, b: Int = 2): Int = {
    return a + b
  }*/
  
   def getSum(a: Int = 10 , b: Int = 20): Int = {
    return a + b
  }

  println(getSum(20, 30))
  println(getSum())
  println(getSum(20))
  println(getSum(b = 20))
  //Function that returns nothing
  def sayHi() {
    println("Hi")
  }
  
  sayHi
  
  //Receive Variable number of Arguments
  
  def getSum2(args:Int*) : Int = {
    var sum:Int = 0
    for(i <- args){
      sum +=i
    }
    sum
  }
  
  println("getSum2 = "+getSum2(1,2,22,4,5,66,7,8,9,5,90,30,29))
  
  //Recursion example of Calculating factorial
  def factorial(num : BigInt) : BigInt = {
    if(num <= 1)
      1
    else
      num * factorial(num -1)
  }
  
  println("factorial(3) = "+factorial(3))
  println("factorial(5) = "+factorial(5))
  println("factorial(8) = "+factorial(8))
  
  //Apply a function to all elements of List using Map method
  val myFunc = log10 _
  
 /* def myFunc2( a:Int): Int = {
    return log10 a
  }*/
  println(myFunc(1000))
  
  
  List(1000.0,10000.0,100000.0).map(myFunc).foreach(println)

  List(1,2,3,4,5,6,7,8,9).map { x => x*50 }.foreach (println) 
  
  List(1,2,3,4,5).filter(x => (x%2 == 0)).foreach {println}
  
  
  
  //pass different function to a function
  
  
  def times3(num:Int): Double ={
    num * 3
  }
  
  def times4(num:Int): Double ={
    num * 4
  }
  
  def multiply(funcName:(Int) => Double,num:Int) = {
    funcName(num)
    //times3(100)
    //times4(100)
  }
  
  println("Multily a function = "+multiply(times3, 100))
  println("Multily a function = "+multiply(times4, 100))
  
  //A closure is a function that depends on a variable declared outside of the function
  val divisorVal = 10
  //val divisor5 = (num : Double) => num/ divisorVal
  
  def divisor5(num : Double){
    num/ divisorVal
  }
  
  println("clouser = "+divisor5(5.0))
  
}