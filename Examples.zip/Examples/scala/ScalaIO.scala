package com

import scala.io.StdIn.{readLine,readInt}
import java.io.PrintWriter
import scala.io.Source
import scala.math._

object ScalaIO extends App{
  /*var numberGuess = 0
  do{
    println("Guess a Number !")
    numberGuess = readLine.toInt
  }while(numberGuess != 15)
    
    println("You Guessed a secret number , cobngratulations !")
  */
  val writer = new PrintWriter("D://parkar.txt")
  writer.write("Hi this is scala file \n this is another line")
  writer.close()
  
  val file = Source.fromFile("D://parkar.txt")
  val lines = file.getLines()
  
  for(line <- lines){
    println(line)
  }
  file.close()
  
  
}