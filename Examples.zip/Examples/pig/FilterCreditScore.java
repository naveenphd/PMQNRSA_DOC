package com.hadoop.pig;

import java.io.IOException;

import org.apache.pig.FilterFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.Tuple;

public class FilterCreditScore extends FilterFunc{

		public Boolean exec(Tuple creditRecord) throws IOException{
			if(creditRecord == null || creditRecord.size() ==0){
				return false;
			}
			try{
				Object object = creditRecord.get(2);
				if(object == null){
					return false;
				}
				int creditScore = (Integer)object;
				if(creditScore > 5){
					return true;
				}else{
					return false;
				}
			}catch(ExecException e){
				throw new IOException(e);
			}
		}
}
