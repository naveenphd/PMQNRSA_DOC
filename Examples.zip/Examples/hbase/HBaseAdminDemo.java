import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;


public class HBaseAdminDemo {

	public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException {
		/*// Instantiating configuration class
		Configuration con = HBaseConfiguration.create();
		// Instantiating HbaseAdmin class
		HBaseAdmin admin = new HBaseAdmin(con);
		// Instantiating table descriptor class
		HTableDescriptor tableDescriptor = new
		HTableDescriptor(TableName.valueOf("emp2"));
		// Adding column families to table descriptor
		tableDescriptor.addFamily(new HColumnDescriptor("personal"));
		tableDescriptor.addFamily(new HColumnDescriptor("professional"));
		// Execute the table through admin
		admin.createTable(tableDescriptor);
		System.out.println(" Table created ");*/
	//read();
	//delete();
	alter();	
	}

	
	public static void list() throws MasterNotRunningException, ZooKeeperConnectionException, IOException{
		
			// Instantiating a configuration class
			Configuration conf = HBaseConfiguration.create();
			// Instantiating HBaseAdmin class
			HBaseAdmin admin = new HBaseAdmin(conf);
			// Getting all the list of tables using HBaseAdmin object
			HTableDescriptor[] tableDescriptor =admin.listTables();
			// printing all the table names.
			for (int i=0;i< tableDescriptor.length;i++ ){
			System.out.println(tableDescriptor[i].getNameAsString());
			}
	}
	
	public static void insert() throws IOException{
		// Instantiating Configuration class
		Configuration config = HBaseConfiguration.create();
		// Instantiating HTable class
		HTable hTable = new HTable(config, "emp");
		// Instantiating Put class
		// accepts a row name.
		Put p = new Put(Bytes.toBytes("row1"));
		
		
		p.add(Bytes.toBytes("contractDetails"),
				Bytes.toBytes("year"),Bytes.toBytes("2016"));
		
		p.add(Bytes.toBytes("personal"),
				Bytes.toBytes("name"),Bytes.toBytes("jaymin"));
				p.add(Bytes.toBytes("personal"),
				Bytes.toBytes("city"),Bytes.toBytes("Bangalore"));
				p.add(Bytes.toBytes("professional"),Bytes.toBytes("designation"),
				Bytes.toBytes("manager"));
				p.add(Bytes.toBytes("professional"),Bytes.toBytes("salary"),
				Bytes.toBytes("50000"));
				// Saving the put Instance to the HTable.
				hTable.put(p);
				System.out.println("data inserted");
				// closing HTable
				hTable.close();
	}
	
	public static void read() throws IOException{
		Configuration config = HBaseConfiguration.create();
		// Instantiating HTable class
		HTable table = new HTable(config, "emp");
		// Instantiating Get class
		Get g = new Get(Bytes.toBytes("row1"));
		// Reading the data
		Result result = table.get(g);
		// Reading values from Result class object
		byte [] value =
		result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("name"));
		
		byte [] value1 =
				result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("city"));
				// Printing the values
				String name = Bytes.toString(value);
				String city = Bytes.toString(value1);
				System.out.println("name: "+ name + " city: "+city);
	}
	
	public static void delete() throws IOException{
		Configuration conf = HBaseConfiguration.create();
		// Instantiating HTable class
		HTable table = new HTable(conf, "emp");
		// Instantiating Delete class
		Delete delete = new Delete(Bytes.toBytes("row1"));
		delete.deleteColumn(Bytes.toBytes("personal"), Bytes.toBytes("name"));
		delete.deleteFamily(Bytes.toBytes("professional"));
		// deleting the data
		table.delete(delete);
		// closing the HTable object
		table.close();
		System.out.println("data deleted.....");
	}
	
	public static void alter() throws MasterNotRunningException, ZooKeeperConnectionException, IOException{
		Configuration conf = HBaseConfiguration.create();
		HBaseAdmin admin = new HBaseAdmin(conf);
		// Instantiating HTable class
		HTable table = new HTable(conf, "emp");
		HColumnDescriptor columnDescriptor =new
		HColumnDescriptor("TEST");
		// Adding column family
		admin.addColumn("emp", columnDescriptor);
		System.out.println("coloumn added");
		
		Put p = new Put(Bytes.toBytes("row1"));
		
		
		p.add(Bytes.toBytes("TEST"),
				Bytes.toBytes("year"),Bytes.toBytes("2016"));
		table.put(p);
		table.close();
	}
	
}
