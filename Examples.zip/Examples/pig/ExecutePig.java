package com.hadoop.pig;

import java.io.IOException;

import org.apache.pig.PigServer;

public class ExecutePig {

	public static void main(String[] args) {
		try{
			PigServer pigServer = new PigServer("local");
			runQuery(pigServer,"/home/user/jaymin/pig_demo/numbers");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void runQuery(PigServer pigServer, String inputFile) throws IOException {
		pigServer.registerQuery("A = LOAD '"+inputFile+"' AS (id:int);");
		pigServer.registerQuery("B = ORDER A by id desc;");
		pigServer.store("B", "/home/user/jaymin/pig_demo/sorted_numbers");
	}

}
