

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object CustTxnObject extends App{
  
  val conf = new SparkConf().setAppName("Max Txn");
  val sc = new SparkContext(conf);
  
  val file =  sc.textFile(args(0))
  
  case class Txn (amount : Int , txnDate : String, product : String)
  
  val txnPair = file.map { x => (
      x.split(",")(2).toInt , 
      Txn(amount = x.split(",")(3).toInt, txnDate = x.split(",")(1), product = x.split(",")(4))
      ) 
   }
 
  val result =   txnPair.reduceByKey((x,y) => if(x.amount > y.amount) x else y)
  
  result.collect().foreach(println)
  
}