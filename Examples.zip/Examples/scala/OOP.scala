package com
class Dog(name: String, sound: String, growl: String) extends Animal(name, sound) {

  def this(name: String, sound: String) {
    this("No Name", sound, "No Growl")
    this.setName(name)
  }

  def this(name: String) {
    this("No Name", "No Sound", "No Growl")
    this.setName(name)
  }

  def this() {
    this("No Name", "No Sound", "No Growl")
  }

  // You can override any other method
  override def toString(): String = {
    return "" + this.name + this.sound + this.growl
  }
}

class Animal(var name: String, var sound: String) {
  this.setName(name)

  // Any code that follows the class name is executed each time an
  // object is created as part of the Primary Constructor

  // This function is defined in the Animal companion object below

  // You must initialize all fields
  // protected means the field can only be accessed directly by methods
  // defined in the class or by subclasses
  // private fields can't be accessed by subclasses of Animal
  // public fields can be accessed directly by anything

  // protected var name = "No Name"
  // protected var sound = "No Sound"

  // Getters and setters are used to protect data
  def getName(): String = name
  def getSound(): String = sound
  def setName(name: String) {
    // Check if the String contains numbers and if so don't allow
    if (!(name.matches(".*\\d+.*")))

      // this allows us to refer to any object without knowing its name
      this.name = name
    else
      this.name = "No Name"
  }
  def setSound(sound: String) {
    this.sound = sound
  }

  // Subclasses can't call this constructor unlike with Java
  def this(name: String) {

    // This calls the primary constructor defined on the class line
    this("No Name", "No Sound")
    this.setName(name)
  }

  def this() {
    // This calls the primary constructor defined on the class line
    this("No Name", "No Sound")
  }

  // You can override any other method
  override def toString(): String = {

    // How to format Strings
    return "namer and sound" + this.name + this.sound
  }

}

trait Flyable {
  def fly: String

}

trait Bulletproof {
  def hitByBullet: String

  // You can define concrete methods in traits
  def ricochet(startSpeed: Double): String = {
    "The bullet ricochets at a speed of " + startSpeed * .75
  }
}

// The first trait starts with extends and then with for each other
class Superhero(val name: String) extends Flyable with Bulletproof {
  def fly = "this.name" + this.name

  def hitByBullet = "The bullet bounces off of " + this.name
}

object OOP extends App {
  val rover = new Animal
  rover.setName("Rover")
  rover.setSound("Woof")
  printf("%s says %s\n", rover.getName, rover.getSound)

  val whiskers = new Animal("Whiskers", "Meow")
  println(s"${whiskers.getName}  says ${whiskers.getSound}")

  println(whiskers.toString)

  val spike = new Dog("Spike", "Woof", "Grrrr")

  spike.setName("Spike")
  println(spike.toString)


  val superman = new Superhero("Superman")
  println(superman.fly)
  println(superman.hitByBullet)
  println(superman.ricochet(2500))
}